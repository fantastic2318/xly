import time
from time import sleep

from selenium import webdriver

from data_fra_v1.Modules.Login import LoginAction
from data_fra_v3.Util.read_excel import ExcelParse
from data_fra_v3.settings.config import testDataPath


def login_test():
    """
    测试登录
    测试脚本文件
    :return:
    """
    try:
        # path = "/usr/local/bin/chromedriver"
        # driver = webdriver.Chrome(executable_path=path)
        # driver.get('http://mail.163.com')
        # driver.maximize_window()
        # loginAction = LoginAction()
        # loginAction.login(driver, 'fantastic2318', 'fantastic12306')

        # 不借助 业务层 直接调用对象层
        # login_page = LoginPage(driver)
        # login_page.switch_frame()
        # login_page.input_username('fantastic2318')
        # login_page.input_password('fantastic12306')

        # 直接调用业务层
        #login_action = LoginAction()
        #login_action.login(driver, 'fantastic2318', 'fantastic12306')


        excel_par = ExcelParse()
        excel_par.load_workbook(testDataPath)
        excel_par.get_sheet_by_name('login')

        # 获取行数  --》 执行几次
        rows = excel_par.get_rows_nums()
        # 获取第一行的值['username','password']
        row1_value = excel_par.get_row_value(1)

        for i in range(2, rows+1):
            row_value = excel_par.get_row_value(i)
            value = dict(zip(row1_value, row_value))  # 组装成字典 便于识别字段{'username':'fantastic2318'}
            if value['is_need_run'].lower() == 'y':
               username = value['username']
               password = value['password']

               path = "/usr/local/bin/chromedriver"
               driver = webdriver.Chrome(executable_path=path)
               driver.get('http://mail.163.com')
               driver.maximize_window()

               login_action = LoginAction()
               login_action.login(driver, username, password)
               time.sleep(3)
               driver.quit()

    except Exception as e:
        raise e


if __name__ == "__main__":
    login_test()