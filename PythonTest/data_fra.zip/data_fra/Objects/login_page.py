from data_fra.Util.find_elements import locate_element


class LoginPage:

    def __init__(self,driver):
        self.driver = driver

    def switch_frame(self):
        """
        切换iframe
        """
        tmp_frame = locate_element(self.driver,'tag name','iframe')
        self.driver.switch_to.frame(tmp_frame)

    def input_username(self,username):
        locate_element(self.driver, 'name', 'email').send_keys(username)


    def input_password(self,password):
        locate_element(self.driver,'name','password').sendkeys(password)


     #def