from data_fra.Objects.login_page import LoginPage
class LoginAction:
    def __init__(self):
        print('===开始登录')
    # 还可以设置成staticmthod
    def login(self,driver,username,password):
        """
        封装登录动作
        :param driver:
        :param username:
        :param password:
        :return:
        """
        try:
           login_page = LoginPage(driver)
           login_page.switch_frame()
           login_page.input_username(username)
           login_page.input_password(password)
        except Exception as e:
            raise e


# if __name__ == "__main__":
#     driver =
