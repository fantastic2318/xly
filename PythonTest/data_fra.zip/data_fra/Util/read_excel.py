class ExcelParse:

    def __init__(self):
        self.workbook = None
        self.sheet = None

    def load_workbook(self,filename):
        """
        加载数据文件
        :param filename:
        :return:
        """
        try:
            self.workbook = load_workbook(filename)
        except Exception as e:
            raise e

    def get_sheet_by_name(self, sheetname):
        """
        获取具体的sheet
        :param sheetname:
        :return:
        """

    def