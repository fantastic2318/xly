from time import sleep

from selenium import webdriver

from data_fra_v1.Modules.Login import LoginAction


def login_test():
    """
    测试登录
    测试脚本文件
    :return:
    """
    try:
        path = "/usr/local/bin/chromedriver"
        driver = webdriver.Chrome(executable_path=path)
        driver.get('http://mail.163.com')
        driver.maximize_window()
        loginAction = LoginAction()
        loginAction.login(driver, 'fantastic2318', 'fantastic12306')
    except Exception as e:
        raise e


if __name__ == "__main__":
    login_test()