from time import sleep

from selenium import webdriver
from data_fra_v1.Util.find_elements import locate_element
"""
页面对象 用于存放页面对象（包含了哪些控件操作、元素定位）
"""


class LoginPage:

    def __init__(self, driver):
        self.driver = driver

    def switch_frame(self):
        """
        切换iframe
        """
        tmp_frame = locate_element(self.driver, 'tag name', 'iframe')
        self.driver.switch_to.frame(tmp_frame)

    def input_username(self, username):
        """
        输入用户名
        :param username:
        :return:
        """
        locate_element(self.driver, 'name', 'email').send_keys(username)

    def input_password(self, password):
        """
        输入密码
        :param password:
        :return:
        """
        locate_element(self.driver, 'name', 'password').send_keys(password)

    def click_loginBtn(self):
        """
        点击登录按钮
        :return:
        """
        locate_element(self.driver, 'id', 'dologin').click()

    def close_page(self):
        """
        关闭当前页面
        :return:
        """
        sleep(5)
        self.driver.close()
# if __name__ == "__main__":
#     path = "/usr/local/bin/chromedriver"
#     driver = webdriver.Chrome(executable_path=path)
#     driver.get('http://mail.163.com')
#     driver.maximize_window()
#     login_page = LoginPage(driver)
#     login_page.switch_frame()
#     login_page.input_username('fantastic2318')
#     login_page.input_password('fantastic12306')
#     sleep(5)
#     driver.close()
