"""
读取.ini文件的工具类
"""
import configparser

from data_fra_v4.settings.config import eleLocationPath


class IniParserFile:
    def __init__(self):
        # 解析文件
        self.cf = configparser.ConfigParser()
        # 传入要解析文件路径--》路径可配置--config.py
        self.cf.read(eleLocationPath)

    def getSection(self, section_name):
        """
        获取这个节的所有键值对
        :param section_name:
        :return:
        """
        option_dict = self.cf.items(section_name)
        return option_dict

    def getOptionValue(self, section_name, option_name):
       """
       获取某个节中的具体某个参数的值
       :param self:
       :param section_name:
       :param option_name:
       :return:
       """
       return self.cf.get(section_name, option_name)


# if __name__ == "__main__":
#     ini_par = IniParserFile()
    #print(ini_par.getSection("163mail_login"))
    #print(ini_par.getOptionValue("163mail_login",'login_page.loginBtn'))