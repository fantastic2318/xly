import time
import unittest
from selenium import webdriver
from data_fra_v4.Modules.Login import LoginAction
from data_fra_v3.Util.read_excel import ExcelParse
from data_fra_v3.settings.config import testDataPath
from data_fra_v4.Util.Log import log
import ddt   # unittest 第三方包 数据驱动参数化

testdata = [
    {'username': 'fantastic2318', 'password': 'fantastic23106'},
    {'username': 'fantastic2319', 'password': 'fantastic23106'}
]


@ddt.ddt
class Login_Test(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        print('基于类级别的方法')

    def setUp(self):
        """
        前置操作打开浏览器 访问网页
        :return:
        """
        path = "/usr/local/bin/chromedriver"
        self.driver = webdriver.Chrome(executable_path=path)
        self.driver.get('http://mail.163.com')
        self.driver.maximize_window()

    def tearDown(self):
        """
        后者操作 关闭浏览器
        :return:
        """
        time.sleep(5)
        self.driver.quit()

    @classmethod
    def tearDownClass(cls) -> None:
        print('基于类级别后置')

    @ddt.data(*testdata)
    def test_login(self, testdata):
        """
        测试用例方法 登录
        :return:
        """
        log.info(testdata)
        username = testdata['username']
        password = testdata['password']
        log.info("V1测试用例 数据驱动")
        loginAction = LoginAction()
        loginAction.login(self.driver, username, password)
        time.sleep(3)
        self.assertIn("fantastic2318", self.driver.page_source)

    # def test_login_v2(self):
    #     """
    #     测试用例方法 登录
    #     :return:
    #     """
    #     log.info("V2*****测试用例")
    #     loginAction = LoginAction()
    #     loginAction.login(self.driver, 'fantastic2318', 'fantastic12306')
    #     time.sleep(3)
    #     self.assertIn("fantastic2318", self.driver.page_source)

# def login_test():
#     """
#     测试登录
#     测试脚本文件
#     :return:
#     """
#     try:
#         log.info('开始执行登录测试')
#         # path = "/usr/local/bin/chromedriver"
#         # driver = webdriver.Chrome(executable_path=path)
#         # driver.get('http://mail.163.com')
#         # driver.maximize_window()
#         # loginAction = LoginAction()
#         # loginAction.login(driver, 'fantastic2318', 'fantastic12306')
#
#         # 不借助 业务层 直接调用对象层
#         # login_page = LoginPage(driver)
#         # login_page.switch_frame()
#         # login_page.input_username('fantastic2318')
#         # login_page.input_password('fantastic12306')
#
#         # 直接调用业务层
#         #login_action = LoginAction()
#         #login_action.login(driver, 'fantastic2318', 'fantastic12306')
#
#
#         excel_par = ExcelParse()
#         excel_par.load_workbook(testDataPath)
#         excel_par.get_sheet_by_name('login')
#
#         # 获取行数  --》 执行几次
#         rows = excel_par.get_rows_nums()
#         # 获取第一行的值['username','password']
#         row1_value = excel_par.get_row_value(1)
#
#         for i in range(2, rows+1):
#             row_value = excel_par.get_row_value(i)
#             value = dict(zip(row1_value, row_value))  # 组装成字典 便于识别字段{'username':'fantastic2318'}
#             if value['is_need_run'].lower() == 'y':
#                username = value['username']
#                password = value['password']
#
#                path = "/usr/local/bin/chromedriver"
#                driver = webdriver.Chrome(executable_path=path)
#                driver.get('http://mail.163.com')
#                driver.maximize_window()
#
#                login_action = LoginAction()
#                login_action.login(driver, username, password)
#                time.sleep(3)
#                driver.quit()
#
#     except Exception as e:
#         raise e



if __name__ == "__main__":
    unittest.main() # 测试当前类当中以Test开头的方法
    #login_test()