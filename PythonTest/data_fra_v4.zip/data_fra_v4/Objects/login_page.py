from time import sleep

from selenium import webdriver
from data_fra_v4.Util.find_elements import locate_element
from data_fra_v4.Util.read_ini import IniParserFile
from data_fra_v4.Util.Log import log

"""
页面对象 用于存放页面对象（包含了哪些控件操作、元素定位）
"""


class LoginPage:

    def __init__(self, driver):
        self.driver = driver
        self.parse = IniParserFile()
        self.login_options = dict(self.parse.getSection("163mail_login"))
        print(self.login_options)

    def switch_frame(self):
        """
        切换iframe
        """
        log.info('执行切换iFrame动作')
        location_type, locate_express = self.login_options["login_page.frame"].split(':')
        tmp_frame = locate_element(self.driver, location_type, locate_express)
        self.driver.switch_to.frame(tmp_frame)

    def input_username(self, username):
        """
        输入用户名
        :param username:
        :return:
        """
        type, expression = self.login_options["login_page.username"].split(":")
        locate_element(self.driver, type, expression).send_keys(username)

    def input_password(self, password):
        """
        输入密码
        :param password:
        :return:
        """
        type, expression = self.login_options['login_page.password'].split(":")
        locate_element(self.driver, type, expression).send_keys(password)

    def click_loginBtn(self):
        """
        点击登录按钮
        :return:
        """
        log.info('登录动作')
        type, expression = self.login_options['login_page.loginBtn'].split(":")
        locate_element(self.driver, type, expression).click()

    def close_page(self):
        """
        关闭当前页面
        :return:
        """
        sleep(5)
        self.driver.close()


# if __name__ == "__main__":
#     path = "/usr/local/bin/chromedriver"
#     driver = webdriver.Chrome(executable_path=path)
#     driver.get('http://mail.163.com')
#     driver.maximize_window()
#     login_page = LoginPage(driver)
#     login_page.switch_frame()
#     login_page.input_username('fantastic2318')
#     login_page.input_password('fantastic12306')
#     sleep(5)
#     driver.close()
