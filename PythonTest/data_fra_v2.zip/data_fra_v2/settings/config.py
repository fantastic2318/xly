import os

# .ini文件路径，当前文件的目录的绝对路径的父目录的父目录
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
eleLocationPath = os.path.join(BASE_DIR, 'settings/element_location.ini')
#print(eleLocationPath)