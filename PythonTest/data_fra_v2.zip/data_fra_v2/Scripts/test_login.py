from time import sleep

from selenium import webdriver

from data_fra_v1.Modules.Login import LoginAction
from data_fra_v2.Objects.login_page import LoginPage


def login_test():
    """
    测试登录
    测试脚本文件
    :return:
    """
    try:
        path = "/usr/local/bin/chromedriver"
        driver = webdriver.Chrome(executable_path=path)
        driver.get('http://mail.163.com')
        driver.maximize_window()
        loginAction = LoginAction()
        loginAction.login(driver, 'fantastic2318', 'fantastic12306')

        # 不借助 业务层 直接调用对象层
        # login_page = LoginPage(driver)
        # login_page.switch_frame()
        # login_page.input_username('fantastic2318')
        # login_page.input_password('fantastic12306')

    except Exception as e:
        raise e


if __name__ == "__main__":
    login_test()